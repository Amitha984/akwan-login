<?php
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];

echo "<h2>Signup Successful!</h2>";
echo "<p>Name: $name</p>";
echo "<p>Email: $email</p>";
?>
