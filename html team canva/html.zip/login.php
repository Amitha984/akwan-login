<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo "<h2 style='font-family:Poppins;text-align:center;margin-top:50px;'>Form submitted successfully ✅</h2>";
    echo "<p style='text-align:center;'>This is just a demo. You can connect to a database later.</p>";
}
?>
