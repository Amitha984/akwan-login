<?php
$email = $_POST['email'];
echo "<h2>Password reset link sent to: $email</h2>";
?>
